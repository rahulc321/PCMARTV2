<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="Love4All" />

	<title>Customer Service </title>
    <link rel="shortcut icon" href="assets/img/favicon.ico">
</head>

<body>
<style type="text/css">
    body {
    margin: 20px;
    /* background: #569e14; */
    background-image: linear-gradient(to right, #63b7ff85, #FFA971) !important;
}
</style>
<link href="/assets/css/bootstrap.min.css" rel="stylesheet">
            	<!-- jQuery -->
	<script src="/assets/js/jquery-3.1.1.min.js"></script>
	
	<!-- Mainly scripts -->    
    <script src="/assets/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <div class="container">
        <div class="row" style="    margin-top: 30px;">
            <div class="col-md-6 col-md-offset-3" style="text-align: center !important;">
            <img src="{{url('/logo/pcmart-gold.png')}}" />
  <h2>Thank you for your Rating.</h2>
                    	<h3 style="/* color: rgb(24, 157, 14); */"> We would appreciate further comments from you to </h3>
        <h3 style="font-size: 24px;line-height: 22px;"> improve our level of service by sending email to </h3>
         <h3 style="font-size: 24px;line-height: 22px;"> <a href="mailto:sales@pcmart.com.my">sales@pcmart.com.my</a></h3>
        	
        
            </div>
        </div>
    </div>
    
    
</body>
</html>