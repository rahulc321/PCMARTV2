Hello Dear,

<p>Please user this OTP : {{$otp}}</p>