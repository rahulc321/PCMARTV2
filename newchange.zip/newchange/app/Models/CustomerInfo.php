<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CustomerInfo extends Model
{
 protected $table = 'arcust_other_info';

 	 


}
