<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ictran extends Model
{
 protected $table = 'ictran';
}
